from flask import Flask, request, jsonify
import json, os, jwt, bcrypt
from flask_cors import CORS
from functools import wraps
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = 'secure_and_long_secret_key_change_this'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_PATH = os.path.join(BASE_DIR, 'users.json')
CARDS_PATH = os.path.join(BASE_DIR, 'cards.json')

if not os.path.exists(USERS_PATH):
    with open(USERS_PATH, 'w') as f:
        json.dump([], f)
if not os.path.exists(CARDS_PATH):
    with open(CARDS_PATH, 'w') as f:
        json.dump([], f)

def read_data(path):
    with open(path, 'r') as f:
        return json.load(f)

def write_data(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            return jsonify({'error': 'Token missing'}), 401
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user_id = data['userId']
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Invalid token'}), 401
        return f(current_user_id, *args, **kwargs)
    return decorated

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    name, email, password, pin = data.get('name'), data.get('email'), data.get('password'), data.get('pin')
    users = read_data(USERS_PATH)

    if any(u['email'] == email for u in users):
        return jsonify({'error': 'Email already exists'}), 400

    hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    users.append({
        'id': len(users) + 1,
        'name': name,
        'email': email,
        'password': hashed_pw,
        'pin': pin
    })
    write_data(USERS_PATH, users)
    return jsonify({'message': 'User registered'}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    email, password = data.get('email'), data.get('password')
    users = read_data(USERS_PATH)
    user = next((u for u in users if u['email'] == email), None)
    if not user or not bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
        return jsonify({'error': 'Invalid credentials'}), 401

    token = jwt.encode({
        'userId': user['id'],
        'exp': datetime.utcnow() + timedelta(days=1)
    }, app.config['SECRET_KEY'], algorithm='HS256')

    return jsonify({'token': token, 'name': user['name']}), 200

@app.route('/api/cards', methods=['POST'])
@token_required
def save_card(user_id):
    data = request.get_json()
    name, number, expiry, cvv = data.get('name'), data.get('number'), data.get('expiry'), data.get('cvv')
    cards = read_data(CARDS_PATH)
    cards.append({'userId': user_id, 'name': name, 'number': number, 'expiry': expiry, 'cvv': cvv})
    write_data(CARDS_PATH, cards)
    return jsonify({'message': 'Card saved'}), 200

@app.route('/api/cards', methods=['GET'])
@token_required
def get_cards(user_id):
    cards = read_data(CARDS_PATH)
    user_cards = [c for c in cards if c['userId'] == user_id]
    safe_cards = [{'name': c['name'], 'number': c['number'][-4:]} for c in user_cards]
    return jsonify(safe_cards), 200

if __name__ == '__main__':
    app.run(port=5000)
