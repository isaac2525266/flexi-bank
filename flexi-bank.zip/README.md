# FLEXI BANK

A simple Flask-based banking backend with:
- User registration and login
- Token-based authentication
- Card storage
- JSON file storage

## Run locally
```bash
pip install -r requirements.txt
python app.py
```
